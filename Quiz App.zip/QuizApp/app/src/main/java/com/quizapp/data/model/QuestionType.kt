package com.quizapp.data.model

enum class QuestionType {
    MULTIPLE_CHOICE,
    SINGLE_CHOICE,
}
