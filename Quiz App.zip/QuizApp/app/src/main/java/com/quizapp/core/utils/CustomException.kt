package com.quizapp.core.utils

class CustomException(
    msg: String
): Exception(msg)