package com.quizapp.data.model

data class User(
    val role: String? = ""
)
