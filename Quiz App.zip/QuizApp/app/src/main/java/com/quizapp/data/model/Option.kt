package com.quizapp.data.model

data class Option(
    var text: String = "",
)
